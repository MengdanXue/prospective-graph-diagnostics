"""Reconstruct post-hoc threshold envelopes and retained task durations.

Standard library only. All input data remain inside the unmodified ESM_1 ZIP.
This script trains no model and never evaluates a checkpoint or held-out node.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
import csv
import hashlib
import json
import math
from pathlib import Path
import zipfile


def digest(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def mean_loss(rows, actions):
    require(len(rows) == len(actions) and rows, 'empty or unpaired actions')
    groups = defaultdict(list)
    for r, a in zip(rows, actions):
        groups[r['dataset']].append(max(r['graph_test'], r['mlp_test']) - r[a + '_test'])
    return 100 * math.fsum(math.fsum(v) / len(v) for v in groups.values()) / len(groups)


def envelope(rows, metric):
    require(rows and len({(r['dataset'], r['seed']) for r in rows}) == len(rows),
            'duplicate or empty rows')
    scores = sorted({r[metric] for r in rows if r[metric] is not None})
    require(all(math.isfinite(v) for v in scores), 'nonfinite score')
    require(all(0 <= r[k] <= 1 for r in rows for k in ['graph_test', 'mlp_test']), 'invalid outcome')
    candidates = [('all_graph', None)] + [('cutoff', v) for v in scores[1:]] + [('all_mlp', None)]

    def decisions(kind, threshold):
        return tuple('mlp' if r[metric] is None or kind == 'all_mlp' else
                     'graph' if kind == 'all_graph' or r[metric] >= threshold else 'mlp' for r in rows)

    vectors = [decisions(k, t) for k, t in candidates]
    trace = [{'kind': k, 'value': t, 'regret_pp': mean_loss(rows, a), 'graph_actions': a.count('graph')}
             for (k, t), a in zip(candidates, vectors)]
    chosen = min(range(len(trace)), key=lambda i: trace[i]['regret_pp'])
    mids = [low + (high - low) / 2 for low, high in zip(scores, scores[1:])]
    mids = [mid if mid > low else high for low, high, mid in zip(scores, scores[1:], mids)]
    independent = [decisions('all_graph', None)] + [decisions('cutoff', m) for m in mids] + [decisions('all_mlp', None)]
    require(set(independent) == set(vectors), 'endpoint/midpoint action families differ')
    require(math.isclose(trace[chosen]['regret_pp'], min(mean_loss(rows, a) for a in independent), abs_tol=1e-11),
            'independent enumeration disagrees')
    graph = mean_loss(rows, ['graph'] * len(rows))
    return {'minimum_regret_pp': trace[chosen]['regret_pp'], 'headroom_pp': graph,
            'headroom_closed_fraction': (graph - trace[chosen]['regret_pp']) / graph if graph else None,
            'chosen': trace[chosen], 'actions': list(vectors[chosen]), 'candidates': trace,
            'missing_scores': sum(r[metric] is None for r in rows),
            'independent_enumeration_verified': True}


def run(supplement, scope):
    require(digest(supplement) == scope['source_zip_sha256'], 'wrong source supplement')
    with zipfile.ZipFile(supplement) as z:
        manifest = json.loads(z.read('MANIFEST.json'))['files']
        verified = {}

        def read(name):
            raw = z.read(name)
            sha = hashlib.sha256(raw).hexdigest()
            require(sha == manifest[name]['sha256'] and len(raw) == manifest[name]['bytes'], 'manifest mismatch: ' + name)
            verified[name] = sha
            return json.loads(raw)

        analysis = read('reader/evidence/review-sensitivity/influence-source-analysis.json')
        metrics = read('reader/evidence/review-sensitivity/published-metrics.json')['metric_records']
        metric_index = {(r['dataset'], r['seed']): r for r in metrics}
        require(len(metric_index) == len(metrics) == 110, 'incomplete metric records')
        indexes = {}
        times = defaultdict(list)
        for group, expected in [('input-retraining', 1540), ('mlp24', 220)]:
            index = {}
            for name in sorted(z.namelist()):
                if not name.startswith('reader/evidence/new-evidence/' + group + '/records/') or not name.endswith('.json'):
                    continue
                r = read(name)
                key = (r['condition'], r['dataset'], r['seed'], r['model'])
                require(key not in index and r['status'] == 'success', 'duplicate/unsuccessful record')
                require(math.isfinite(r['duration_seconds']) and r['duration_seconds'] >= 0, 'invalid duration')
                require(r['test_evaluations_after_selection'] == 1, 'unexpected test accounting')
                index[key] = r
                times[(group, r['condition'], r['model'], r['environment']['device'])].append(r['duration_seconds'])
            require(len(index) == expected, 'incomplete raw record group')
            indexes[group] = index

        cells = []
        expected = {(c, b, tuple(sorted(p))) for c in scope['conditions'] for b in scope['budgets'] for p in scope['portfolios']}
        observed = set()
        for cell in analysis['cells']:
            condition, budget, portfolio = cell['condition'], cell['budget'], cell['portfolio']
            identity = condition, budget, tuple(sorted(portfolio))
            require(identity in expected and identity not in observed, 'unexpected/duplicate configuration')
            observed.add(identity)
            rows = cell['rows']
            require(len(rows) == 110 and len({(r['dataset'], r['seed']) for r in rows}) == 110,
                    'incomplete outcome scope')
            for row in rows:
                dataset, seed = row['dataset'], row['seed']
                graph = min((indexes['input-retraining'][condition, dataset, seed, model] for model in portfolio),
                            key=lambda r: (-r['validation_accuracy'], r['model']))
                mlp = indexes['input-retraining' if budget == 4 else 'mlp24'][condition, dataset, seed, 'MLP']
                metric = metric_index[dataset, seed]
                require(graph['split_id'] == mlp['split_id'] == metric['split_id'], 'split mismatch')
                require(row['graph_model'] == graph['model'] and row['graph_test'] == graph['test_accuracy']
                        and row['mlp_test'] == mlp['test_accuracy'], 'candidate reselection mismatch')
                require(row['homophily'] == graph['diagnostics']['homophily'], 'homophily mismatch')
                for m in ['adjusted_homophily', 'edge_label_informativeness']:
                    require(row[m] == metric['metrics'][m]['value'], 'published metric mismatch')
            results = {}
            for metric in scope['metrics']:
                e = envelope(rows, metric)
                lodo = cell['matched_lodo_verified'][metric]
                choices = {(r['dataset'], r['seed']): ('mlp' if r['action'] == 'abstain' else r['action'])
                           for r in lodo['outcomes']}
                actual = mean_loss(rows, [choices[r['dataset'], r['seed']] for r in rows])
                require(math.isclose(actual, lodo['mean_regret_pp'], abs_tol=1e-10), 'saved LODO loss mismatch')
                results[metric] = {**e, 'lodo_regret_pp': actual,
                                   'lodo_minus_global_minimum_pp': actual - e['minimum_regret_pp']}
            cells.append({'condition': condition, 'budget': budget, 'portfolio': portfolio,
                          'units': len(rows), 'datasets': len({r['dataset'] for r in rows}),
                          'always_graph_pp': mean_loss(rows, ['graph'] * len(rows)),
                          'always_mlp_pp': mean_loss(rows, ['mlp'] * len(rows)), 'metrics': results})
        require(observed == expected, 'missing configurations')
    time_rows = [{'group': g, 'condition': c, 'model': m, 'device': d, 'records': len(values),
                  'duration_seconds': math.fsum(values), 'duration_hours': math.fsum(values)/3600}
                 for (g, c, m, d), values in sorted(times.items())]
    return {'schema': 'threshold-cost-results/1', 'analysis_status': scope['analysis_status'],
            'scope': scope, 'input_member_sha256': verified, 'cells': cells, 'runtime': time_rows,
            'checks': {'raw_records_bound': 1760, 'metric_cells': 48, 'new_training': 0,
                       'all_endpoint_midpoint_families_agree': True, 'all_saved_lodo_losses_reconstructed': True}}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--supplement', type=Path, required=True)
    p.add_argument('--scope', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    require(not args.output.exists(), 'output exists; preserve completed evidence')
    scope = json.loads(args.scope.read_text(encoding='utf-8'))
    result = run(args.supplement, scope)
    result['provenance'] = {'script_sha256': digest(__file__), 'scope_sha256': digest(args.scope),
                            'source_zip_sha256': digest(args.supplement)}
    args.output.mkdir(parents=True)
    (args.output/'analysis.json').write_text(json.dumps(result, indent=2, allow_nan=False)+'\n', encoding='utf-8')
    with (args.output/'thresholds.csv').open('w', newline='', encoding='utf-8') as f:
        fields = ['condition', 'budget', 'portfolio', 'metric', 'headroom_pp', 'minimum_regret_pp',
                  'headroom_closed_fraction', 'lodo_regret_pp', 'lodo_minus_global_minimum_pp', 'missing_scores']
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader()
        for c in result['cells']:
            for m, r in c['metrics'].items():
                w.writerow({'condition': c['condition'], 'budget': c['budget'], 'portfolio': '+'.join(c['portfolio']),
                            'metric': m, **{k: r[k] for k in fields[4:]}})
    with (args.output/'runtime.csv').open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(result['runtime'][0])); w.writeheader(); w.writerows(result['runtime'])
    print(json.dumps(result['checks']))
    for c in result['cells']:
        print(c['condition'], c['budget'], '+'.join(c['portfolio']), 'graph', round(c['always_graph_pp'], 4),
              {m: round(v['minimum_regret_pp'], 4) for m, v in c['metrics'].items()})


if __name__ == '__main__':
    main()
