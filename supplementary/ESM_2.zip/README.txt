Online Resource 2: Threshold envelopes and retained execution-time accounting

Article title: From Graph Diagnostics to Model Decisions: Portfolio, Fallback, and Calibration
Journal: Applied Intelligence (Springer Nature)
Author: Mengdan Xue
Affiliation: Faculty of Computational Mathematics and Cybernetics, Lomonosov Moscow State University, Moscow, Russia
Corresponding author email: 17326961775@163.com

This archive is cited in the manuscript as Online Resource 2 (ESM_2.zip). It contains
post-hoc global threshold envelopes for three statistics across 16 configurations,
recorded execution-time accounting, the fixed analysis scope, and reproduction code.
The results are descriptive reanalysis of retained outcomes; no new neural or
classifier fitting is performed. The source archive and checksums are identified in
MANIFEST.json. Supplementary information is provided as received by the authors.

Reproduction (Python 3.11 or newer; standard library only; from this directory):
python scripts/reviewer_threshold_cost.py --supplement /path/to/ESM_1.zip --scope configs/scope.json --output reproduced
python -m unittest discover -s tests
