import unittest

from scripts.reviewer_threshold_cost import envelope, mean_loss


class ThresholdEnvelopeTests(unittest.TestCase):
    def test_equal_dataset_weight_not_equal_row_weight(self):
        rows = [{'dataset': 'A', 'seed': i, 'score': 0.1, 'graph_test': 0.0, 'mlp_test': 1.0}
                for i in range(10)] + [{'dataset': 'B', 'seed': 0, 'score': 0.9, 'graph_test': 1.0, 'mlp_test': 0.0}]
        self.assertEqual(mean_loss(rows, ['graph'] * 11), 50.0)
        result = envelope(rows, 'score')
        self.assertEqual(result['minimum_regret_pp'], 0.0)
        self.assertEqual(result['actions'], ['mlp'] * 10 + ['graph'])

    def test_identical_scores_cannot_separate_opposite_winners(self):
        rows = [{'dataset': 'A', 'seed': 0, 'score': 0.2, 'graph_test': 0.0, 'mlp_test': 1.0},
                {'dataset': 'B', 'seed': 0, 'score': 0.2, 'graph_test': 1.0, 'mlp_test': 0.0}]
        result = envelope(rows, 'score')
        self.assertEqual(result['minimum_regret_pp'], 50.0)
        self.assertEqual(result['chosen']['kind'], 'all_graph')

    def test_missing_statistic_keeps_declared_mlp_fallback(self):
        rows = [{'dataset': 'A', 'seed': 0, 'score': None, 'graph_test': 1.0, 'mlp_test': 0.0},
                {'dataset': 'B', 'seed': 0, 'score': 0.2, 'graph_test': 1.0, 'mlp_test': 0.0}]
        result = envelope(rows, 'score')
        self.assertEqual(result['minimum_regret_pp'], 50.0)
        self.assertEqual(result['missing_scores'], 1)
        self.assertEqual(result['actions'], ['mlp', 'graph'])

    def test_fold_dependent_choices_can_outperform_global_threshold(self):
        rows = [{'dataset': 'A', 'seed': 0, 'score': 0.1, 'graph_test': 1.0, 'mlp_test': 0.0},
                {'dataset': 'B', 'seed': 0, 'score': 0.2, 'graph_test': 0.0, 'mlp_test': 1.0}]
        self.assertEqual(envelope(rows, 'score')['minimum_regret_pp'], 50.0)
        self.assertEqual(mean_loss(rows, ['graph', 'mlp']), 0.0)

    def test_duplicate_units_and_nonfinite_scores_rejected(self):
        row = {'dataset': 'A', 'seed': 0, 'score': 0.1, 'graph_test': 1.0, 'mlp_test': 0.0}
        with self.assertRaises(ValueError):
            envelope([row, row], 'score')
        with self.assertRaises(ValueError):
            envelope([{**row, 'score': float('nan')}], 'score')


if __name__ == '__main__':
    unittest.main()
